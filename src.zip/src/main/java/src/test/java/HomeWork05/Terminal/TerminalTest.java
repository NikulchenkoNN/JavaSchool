package HomeWork05.Terminal;

import HomeWork05.Exceptions.AccountIsLockedException;
import HomeWork05.Exceptions.InvalidENterState;
import HomeWork05.Exceptions.NotEnoughMoneyException;
import HomeWork05.Exceptions.NumberIsNotMultipleException;
import org.junit.Test;

import java.io.IOException;

public class TerminalTest {
    @Test
    public void test() throws AccountIsLockedException, IOException, InvalidENterState, NotEnoughMoneyException, NumberIsNotMultipleException {
        int[] pin = new int[]{1, 2, 3, 4};
        BankAccount account = new BankAccount(pin);
//        TerminalServer server = new TerminalServer(500);
        PinValidator validator = new PinValidator(account);
//        TerminalImpl terminal = new TerminalImpl(server, validator, account);


        int[] pinToCheck = validator.readPin();
    }
}