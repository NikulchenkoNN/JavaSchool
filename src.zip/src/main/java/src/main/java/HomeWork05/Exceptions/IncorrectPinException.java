package HomeWork05.Exceptions;

public class IncorrectPinException extends Exception{
    public IncorrectPinException(String message) {
        super(message);
    }
}
