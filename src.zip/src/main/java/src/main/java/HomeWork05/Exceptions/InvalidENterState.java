package HomeWork05.Exceptions;

public class InvalidENterState extends Exception{
    public InvalidENterState(String message) {
        super(message);
    }
}
