package HomeWork05.Exceptions;

public class NumberIsNotMultipleException extends Exception{
    public NumberIsNotMultipleException(String message) {
        super(message);
    }
}
