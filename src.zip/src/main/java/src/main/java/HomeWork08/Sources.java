package HomeWork08;

public enum Sources {
    FILE,
    MAP
}
