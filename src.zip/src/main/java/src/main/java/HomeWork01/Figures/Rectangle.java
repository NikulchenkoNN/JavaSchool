package HomeWork01.Figures;

public class Rectangle extends Figure{
}
