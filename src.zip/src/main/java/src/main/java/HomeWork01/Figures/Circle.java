package HomeWork01.Figures;

public class Circle extends Figure{
}
