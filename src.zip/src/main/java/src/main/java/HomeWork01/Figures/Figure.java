package HomeWork01.Figures;

public class Figure {
}
