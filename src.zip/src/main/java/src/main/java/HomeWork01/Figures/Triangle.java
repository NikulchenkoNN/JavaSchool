package HomeWork01.Figures;

public class Triangle extends Figure{
}
