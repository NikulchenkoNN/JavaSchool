package HomeWork01.Figures;

public class Square extends Rectangle{
}
