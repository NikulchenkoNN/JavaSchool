package HomeWork07.MyClassLoader;

import HomeWork08.CachedInvocationHandler;
import HomeWork08.Service;
import HomeWork08.ServiceImpl;

public class Main {
    public static void main(String[] args) {

    }

}
