package HomeWork07.MyClassLoader;

public interface Plugin {
    void doUseful();
}
