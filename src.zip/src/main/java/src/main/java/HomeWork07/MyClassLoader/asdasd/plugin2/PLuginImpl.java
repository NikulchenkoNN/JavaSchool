package HomeWork07.MyClassLoader.asdasd.plugin2;

import HomeWork07.MyClassLoader.Plugin;

public class PLuginImpl implements Plugin {
    @Override
    public void doUseful() {
        System.out.println("Correct, second file");
    }
}
